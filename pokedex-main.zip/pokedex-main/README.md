# Pokédex con PokéAPI

#### Aquí podrán encontrar los archivos que utilicé en este video.

El video está en YouTube, [haciendo clic aquí](https://youtu.be/EmxvMPcIy5c).

### Autor
- Carpi Coder

### Contacto
- [www.carpicoder.com](https://carpicoder.com)
- [hola@carpicoder.com](mailto:hola@carpicoder.com)

### Redes sociales
- [YouTube](https://youtube.com/carpicoder)
- [Instagram](https://instagram.com/carpicoder)
- [TikTok](https://tiktok.com/@carpicoder)
- [X](https://twitter.com/carpicoder)
- [Discord](https://discord.gg/wHKxGbMt4A)
- [LinkedIn](https://linkedin.com/in/matiascoletta)

#### Para apoyar mi contenido, podés entrar en [carpicoder.com/donaciones](https://carpicoder.com/donaciones)
