import Header from '../cmps/Header';
import PokemonList from '../cmps/PokemonList';
const List = ()=>{
    return (
        <>
            <Header />
            <PokemonList />
        </>
    );
}

export default List;